exports.users = require("./users");
exports.renters = require("./owner");
exports.customers = require("./customer");
exports.admin = require("./admin");
exports.properties = require("./properties");
exports.bookings = require("./booking");

