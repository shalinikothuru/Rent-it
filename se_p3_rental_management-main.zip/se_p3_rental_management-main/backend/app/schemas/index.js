exports.accountNewSchema = require('./accountNew.json');
exports.loginSchema = require('./login.json');
exports.logoutSchema = require('./logout.json');
exports.homeSchema = require('./homeSchema.json');
exports.addPropertySchema = require('./addPropertySchema.json');
