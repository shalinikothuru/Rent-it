exports.errorHandler = require("./error");
exports.authHandler = require("./auth");
exports.adminHandler = require("./admin");
exports.propertiesHandler = require("./properties");
exports.userHandler = require("./user");
exports.renterHandler = require("./renter");