exports.apiRouter = require("./api");
exports.renterRouter = require("./renter");
exports.adminRouter = require("./admin");
exports.publicRouter = require("./public");
exports.customerRouter = require("./customer");
