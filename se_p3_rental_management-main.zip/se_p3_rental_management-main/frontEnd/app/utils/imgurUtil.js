
export function imgurUrl(id) {
  return "https://i.imgur.com/" + id + ".jpeg";
}